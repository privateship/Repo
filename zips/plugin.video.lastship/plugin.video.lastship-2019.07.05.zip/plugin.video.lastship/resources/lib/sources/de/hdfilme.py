# -*- coding: UTF-8 -*-

import json
import re
import urllib

import urlparse

from resources.lib.modules import cache
import cfscrape
from resources.lib.modules import cleantitle
from resources.lib.modules import directstream
from resources.lib.modules import dom_parser
from resources.lib.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['hdfilme.cc']
        self.base_link = 'https://hdfilme.cc'
        self.search_link = '/search?key=%s'
        self.get_link = 'movie/load-stream/%s/%s?'
        self.scraper = cfscrape.create_scraper()

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            titles = [localtitle] + source_utils.aliases_to_array(aliases)
            url = self.__search(titles, year)
            if not url and title != localtitle: url = self.__search([title] + source_utils.aliases_to_array(aliases), year)
            if not url:
                from resources.lib.modules import searchEngine
                url = searchEngine.search(titles, year, self.domains[0], '(.*?)\sstream')
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            return {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'localtvshowtitle': localtvshowtitle, 'aliases': aliases, 'year': year}
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return

            data = url
            tvshowtitle = data['tvshowtitle']
            aliases = source_utils.aliases_to_array(data['aliases'])
            aliases.append(data['localtvshowtitle'])

            url = self.__search([tvshowtitle] + aliases, data['year'], season)
            if not url: return

            urlWithEpisode = url+"?folge-"+str(episode)
            return source_utils.strip_domain(urlWithEpisode)
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url:
                return sources

            moviecontent = cache.get(self.scraper.get, 48, urlparse.urljoin(self.base_link, url), headers={'referer': urlparse.urljoin(self.base_link, url)})

            url = url.replace('-info', '-stream')
            r = re.findall('(\d+)-stream(?:\?folge-(\d+))?', url)
            r = [(i[0], i[1] if i[1] else '1') for i in r][0]

            streamlink = dom_parser.parse_dom(moviecontent.content, 'a', attrs={'class': 'new'})
            r = (r[0], streamlink[int(r[1])-1].attrs['data-episode-id'])

            for server in ['', 'server=2']:
                link = self.get_link + server
                moviesource = cache.get(self.scraper.get, 4, urlparse.urljoin(self.base_link, link % r), headers={'referer': urlparse.urljoin(self.base_link, url)})

                foundsource = re.findall('var sources = (\[.*?\]);', moviesource.content)
                if any(foundsource):
                    foundsource = re.findall('sources\s=\s(\[{(.|\n|\r)*?\])', moviesource.content)[0]

                sourcejson = json.loads(foundsource[0].replace('\'', '"'))

                for sourcelink in sourcejson:
                    try:
                        tag = directstream.googletag(sourcelink['file'])
                        if tag:
                            sources.append({'source': 'gvideo', 'quality': tag[0].get('quality', 'SD'), 'language': 'de', 'url': sourcelink['file'], 'direct': True, 'debridonly': False})
                        else:
                            if sourcelink['label'] == 'm3u8':
                                quality = "HD"
                            else:
                                quality = sourcelink['label']
                            sources.append({'source': 'CDN', 'quality': quality, 'language': 'de', 'url': sourcelink['file'], 'direct': True, 'debridonly': False})
                    except:
                        pass
            if not any(sources):
                raise Exception()

            return sources
        except:
            cache.clearFunc(self.scraper.get, urlparse.urljoin(self.base_link, url), headers={'referer': urlparse.urljoin(self.base_link, url)})

            return sources

    def resolve(self, url):
        return url

    def __search(self, titles, year, season='0'):
        try:
            query = self.search_link % (urllib.quote_plus(cleantitle.query(titles[0])))
            query = urlparse.urljoin(self.base_link, query)

            titles = [cleantitle.get(i) for i in set(titles) if i]

            searchResult = cache.get(self.scraper.get, 48, query, headers={'Referer': self.base_link}).content

            resultTitles = dom_parser.parse_dom(searchResult, 'div', attrs={'class': 'body-section'})
            resultTitles = dom_parser.parse_dom(resultTitles, 'div', attrs={'class': 'title-product'})
            resultTitles = dom_parser.parse_dom(resultTitles, 'a')
            resultTitles = [(i.attrs['href'], i.content.split('(')[0]) for i in resultTitles]

            usedIndex = 0

            for link, title in resultTitles:
                title = cleantitle.get(title)
                if any(i in title for i in titles):
                    if season == "0" or ("staffel" in title and ("0"+str(season) in title or str(season) in title)):
                        #We have the suspected link!
                        return source_utils.strip_domain(link)
                usedIndex += 1

            raise Exception()
        except:
            cache.clearFunc(self.scraper.get, query, headers={'Referer': self.base_link})
            return
