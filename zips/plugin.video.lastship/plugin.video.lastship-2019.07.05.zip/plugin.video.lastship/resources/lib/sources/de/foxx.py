# -*- coding: utf-8 -*-

import base64
import json
import re
import urllib
import urlparse

from resources.lib.modules import anilist, cache
import cfscrape
from resources.lib.modules import dom_parser
from resources.lib.modules import source_utils
from resources.lib.modules import tvmaze


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['foxx.to']
        self.base_link = 'https://foxx.to'
        self.search_link = '/eu/?s=%s'
        self.scraper = cfscrape.create_scraper()

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.__search([localtitle] + source_utils.aliases_to_array(aliases), year)
            if not url and title != localtitle: url = self.__search([title] + source_utils.aliases_to_array(aliases), year)
            if not url and source_utils.is_anime('movie', 'imdb', imdb): url = self.__search([anilist.getAlternativTitle(title)] + source_utils.aliases_to_array(aliases), year)
            
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            linkAndTitle = self.__search([tvshowtitle, localtvshowtitle] + source_utils.aliases_to_array(aliases), year)
            aliases = source_utils.aliases_to_array(aliases)

            if not tvshowtitle and source_utils.is_anime('show', 'tvdb', tvdb): linkAndTitle = self.__search([tvmaze.tvMaze().showLookup('thetvdb', tvdb).get('name')] + source_utils.aliases_to_array(aliases), year)

            return linkAndTitle
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            url = urlparse.urljoin(self.base_link, url)
            r = cache.get(self.scraper.get, 48, url).content

            if season == 1 and episode == 1:
                season = episode = ''

            r = dom_parser.parse_dom(r, 'ul', attrs={'class': 'episodios'})
            r = dom_parser.parse_dom(r, 'a', attrs={'href': re.compile('[^\'"]*%s' % ('-%sx%s' % (season, episode)))})[0].attrs['href']
            return source_utils.strip_domain(r)
        except:
            cache.clearFunc(self.scraper.get, url)
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url:
                return sources

            url = urlparse.urljoin(self.base_link, url)
            temp = cache.get(self.scraper.get, 48, url)
            iframes = dom_parser.parse_dom(temp.content, 'iframe')
            iframes = [i.attrs['src'] for i in iframes]
            iframes = ["https:" + i if i.startswith('//') else i for i in iframes]
            iframes = [self.base_link + i if i.startswith('/') else i for i in iframes]

            for link in iframes:
                if 'youtube' in link:
                    continue
                if 'encrypt' in link:
                    r = self.scraper.get(link, headers={'referer': url}, cookies={'noprpkedvhozafiwrcnt': '1'}).content
                    phrase = dom_parser.parse_dom(r, 'iframe')[0].attrs['src']
                    phrase = str(phrase).replace('@','')
                else:
                    r = self.scraper.get(link, headers={'referer': url}, timeout=7).content
                    if 'watch' in link:
                        phrase = re.findall("file\":\s\"(.*?)\"", r)
                    else:
                        phrase = re.findall("(?:jbdaskgs|m3u8File).*?\'(.+?)\\'", r)
                    if phrase:
                        phrase = phrase[0]

                if "m3u8File" in r and phrase:
                    domain = re.findall("urlVideo.*?\'(.*streamservice.online)", r)[0]
                    link = '%s/public/dist/index.html?id=%s' % (domain, phrase)
                    valid, hoster = source_utils.is_host_valid(link, hostDict)
                    if valid:
                        sources.append({'source': hoster, 'quality': '720p', 'language': 'de', 'url': link, 'direct': False,
                             'debridonly': False})
                elif "jbdaskgs" in r and phrase:
                    links = json.loads(base64.b64decode(phrase))
                    [sources.append({'source': 'CDN', 'quality': i['label'] if i['label'] in ['720p', '1080p'] else 'SD',
                                     'language': 'de', 'url': i['file'], 'direct': True, 'debridonly': False}) for i in links]
                elif phrase:
                    valid, hoster = source_utils.is_host_valid(phrase, hostDict)
                    if valid:
                        sources.append({'source': hoster, 'quality': '720p', 'language': 'de', 'url': phrase, 'direct': 'gvideo' in hoster.lower(), 'debridonly': False})

            if len(sources) == 0:
                raise Exception()
            return sources
        except:
            cache.clearFunc(self.scraper.get, url)
            return sources

    def resolve(self, url):
        return url + source_utils.append_headers({'Origin': self.base_link})

    def __search(self, titles, year):
        try:
            query = self.search_link % (urllib.quote_plus(titles[0]))
            query = urlparse.urljoin(self.base_link, query)

            r = cache.get(self.scraper.get, 48, query).content
            dom_parsed = dom_parser.parse_dom(r, 'div', attrs={'class': 'details'})
            links = [(dom_parser.parse_dom(i, 'a')[0], dom_parser.parse_dom(i, 'span', attrs={'class' : 'year'})[0].content) for i in dom_parsed]

            r = sorted(links, key=lambda i: int(i[1]), reverse=True)  # with year > no year
            r = [x[0].attrs['href'] for x in r if int(x[1]) == int(year)]

            if len(r) > 0:
                return source_utils.strip_domain(r[0])
            else:
                raise Exception()

        except:
            cache.clearFunc(self.scraper.get, query)
            return
