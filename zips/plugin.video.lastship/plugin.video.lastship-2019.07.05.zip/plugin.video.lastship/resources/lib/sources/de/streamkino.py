# -*- coding: utf-8 -*-

import re
import urlparse
import base64

from resources.lib.modules import cache
from resources.lib.modules import client
from resources.lib.modules import cleantitle
import cfscrape
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['streamkino.to']
        self.base_link = 'https://streamkino.to'
        self.search_link = '/?s=%s'
        self.stream_link = self.base_link + '/?trembed='
        self.scraper = cfscrape.create_scraper()

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.__search([localtitle] + source_utils.aliases_to_array(aliases), year)
            if not url and title != localtitle: url = self.__search([title] + source_utils.aliases_to_array(aliases), year)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url:
                return sources
            query = urlparse.urljoin(self.base_link, url)
            r = cache.get(self.scraper.get, 48, query).content

            link = '&' + str(dom_parser.parse_dom(r, 'iframe')[0].attrs['src']).split("&")[1]
            links = len(re.findall('(\?trembed.*?)&quot', r))

            for i in range(0, links):
                stream = cache.get(self.scraper.get, 8, client.replaceHTMLCodes(self.stream_link + str(i) + link + "&trtype=1")).content
                stream = dom_parser.parse_dom(stream, 'iframe')[0].attrs['src']

                valid, hoster = source_utils.is_host_valid(stream, hostDict)
                if not valid:
                    continue

                quality, info = source_utils.get_release_quality(stream)

                sources.append({'source': hoster, 'quality': quality, 'language': 'de', 'url': stream, 'direct': False,
                                'debridonly': False, 'checkquality': True})

            if len(sources) == 0:
                raise Exception()
            return sources
        except:
            cache.clearFunc(self.scraper.get, query)
            return sources

    def resolve(self, url):
        return url

    def __search(self, titles, year):
        try:
            query = self.search_link % titles[0]
            query = urlparse.urljoin(self.base_link, query)

            t = [cleantitle.get(i) for i in set(titles) if i]

            r = cache.get(self.scraper.get, 48, query).content

            links = dom_parser.parse_dom(r, 'article')
            links = [dom_parser.parse_dom(i, 'a')[0] for i in links]
            links = [(i.attrs['href'], dom_parser.parse_dom(i, 'h3')[0].content, dom_parser.parse_dom(i, 'span', attrs={'class': 'Year'})[0].content) for i in links]
            links = [i[0] for i in links if cleantitle.get(i[1]) in t and year == i[2]]
            if len(links) == 0:
                raise Exception()
            return links[0]
        except:
            cache.clearFunc(self.scraper.get, query)
            return
