# -*- coding: UTF-8 -*-

def lang(i, lang):

  
    if lang == 'de':
        i = i.replace('Action', u'\u0041\u0063\u0074\u0069\u006f\u006e')
        i = i.replace('Adventure', u'\u0041\u0062\u0065\u006e\u0074\u0065\u0075\u0065\u0072')
        i = i.replace('Animation', u'\u0041\u006e\u0069\u006d\u0061\u0074\u0069\u006f\u006e')
        i = i.replace('Anime', u'Anime')
        i = i.replace('Biography', u'Biography')
        i = i.replace('Comedy', u'\u004b\u006f\u006d\u00f6\u0064\u0069\u0065')
        i = i.replace('Crime', u'\u004b\u0072\u0069\u006d\u0069')
        i = i.replace('Documentary', u'\u0044\u006f\u006b\u0075\u006d\u0065\u006e\u0074\u0061\u0072\u0066\u0069\u006c\u006d')
        i = i.replace('Drama', u'\u0044\u0072\u0061\u006d\u0061')
        i = i.replace('Family', u'\u0046\u0061\u006d\u0069\u006c\u0069\u0065')
        i = i.replace('Fantasy', u'\u0046\u0061\u006e\u0074\u0061\u0073\u0079')
        i = i.replace('Game-Show', u'Game-Show')
        i = i.replace('History', u'\u0048\u0069\u0073\u0074\u006f\u0072\u0069\u0065')
        i = i.replace('Horror', u'\u0048\u006f\u0072\u0072\u006f\u0072')
        i = i.replace('Music ', u'\u004d\u0075\u0073\u0069\u006b')
        i = i.replace('Musical', u'Musical')
        i = i.replace('Mystery', u'\u004d\u0079\u0073\u0074\u0065\u0072\u0079')
        i = i.replace('News', u'News')
        i = i.replace('Reality-TV', u'Reality-TV')
        i = i.replace('Romance', u'\u004c\u006f\u0076\u0065\u0073\u0074\u006f\u0072\u0079')
        i = i.replace('Science Fiction', u'\u0053\u0063\u0069\u0065\u006e\u0063\u0065 \u0046\u0069\u0063\u0074\u0069\u006f\u006e')
        i = i.replace('Sci-Fi', u'\u0053\u0063\u0069\u0065\u006e\u0063\u0065 \u0046\u0069\u0063\u0074\u0069\u006f\u006e')
        i = i.replace('Sport', u'Sport')
        i = i.replace('Talk-Show', u'Talk-Show')
        i = i.replace('Thriller', u'\u0054\u0068\u0072\u0069\u006c\u006c\u0065\u0072')
        i = i.replace('War', u'\u004b\u0072\u0069\u0065\u0067\u0073\u0066\u0069\u006c\u006d')
        i = i.replace('Western', u'\u0057\u0065\u0073\u0074\u0065\u0072\u006e')

    return i


