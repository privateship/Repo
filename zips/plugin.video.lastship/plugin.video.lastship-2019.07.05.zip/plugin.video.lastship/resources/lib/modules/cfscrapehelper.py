from resources.lib.modules import cache, control, workers
from resources.lib.sources import sources
import cfscrape

key = "cfscrapeDummy"

def checkScraper():
    workers.Thread(worker).start()

def worker():
    cache_result = cache.cache_get(key)
    if cache_result:
        if cache._is_cache_valid(cache_result['date'], 1):
            return

    cache.cache_insert(key, "dummyrecord")
    sourceDict = sources()

    try:
        sourceDict = [(i[0], i[1], control.setting('provider.' + i[0])) for i in sourceDict]
    except:
        sourceDict = [(i[0], i[1], 'true') for i in sourceDict]
    sourceDict = [(i[0], i[1]) for i in sourceDict if not i[2] == 'false']

    for name, scraper in sourceDict:
        if hasattr(scraper, 'scraper'):
            workers.Thread(cfscrape.create_scraper().get, scraper.base_link).start()
