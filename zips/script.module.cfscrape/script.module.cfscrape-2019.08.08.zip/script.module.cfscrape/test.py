from datetime import datetime
from lib import cfscrape

scraper = cfscrape.create_scraper()

print datetime.now()

hd_streams = scraper.get("https://hd-streams.org")
print datetime.now()

print("Code: " + str(hd_streams.status_code))
