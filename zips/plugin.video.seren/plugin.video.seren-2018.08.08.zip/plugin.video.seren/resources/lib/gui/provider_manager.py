# -*- coding: utf-8 -*-

import json
import os
import threading
import time

from resources.lib.common import tools

class ProviderManager(tools.dialogWindow):

    def __init__(self):
        super(ProviderManager, self).__init()
        width = 850
        height = 480

        

